
import { GoogleGenAI, Type } from "@google/genai";
import { BacteriaType, ClinicalCase, ClinicalCategory, AIQuizChallengeData } from "../types";
import { SYSTEM_INSTRUCTION, BACTERIA_DATA } from "../constants";

export const generateClinicalCases = async (
  bacteria: BacteriaType,
  category: ClinicalCategory,
  count: number = 3
): Promise<ClinicalCase[]> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API Key is missing provided");
    throw new Error("API Key configuration missing");
  }

  // Initialize client inside the function to ensure the latest API Key is used
  const ai = new GoogleGenAI({ apiKey });

  const bacteriaInfo = BACTERIA_DATA[bacteria];
  
  let contextDescription = "";
  let focusInstructions = "";

  if (category === 'UPPER') {
    contextDescription = "INFECÇÕES RESPIRATÓRIAS ALTAS (IVAS)";
    focusInstructions = "Foque em Faringite, Otite, Sinusite. Descreva orofaringe e otoscopia.";
  } else if (category === 'LOWER') {
    contextDescription = "INFECÇÕES RESPIRATÓRIAS BAIXAS (Pneumonia/Bronquite)";
    focusInstructions = "Foque em Pneumonia/NAC. Descreva ausculta pulmonar e RX de tórax.";
  } else if (category === 'CNS') {
    contextDescription = "INFECÇÕES DO SISTEMA NERVOSO CENTRAL (Meningite)";
    focusInstructions = "Foque OBRIGATORIAMENTE em Meningite. Descreva Sinais Meníngeos (Rigidez de nuca, Kernig, Brudzinski), Estado Mental e ANÁLISE DO LÍQUOR (LCR - Células, Glicose, Proteínas).";
  } else if (category === 'ITU') {
    contextDescription = "INFECÇÕES DO TRATO URINÁRIO (Cistite/Pielonefrite)";
    focusInstructions = "Foque em Disúria, Polaciúria, Dor Lombar/Suprapúbica e Febre. Descreva exame de urina (Nitrito, Leucócitos, pH) e Urocultura. Diferencie Cistite de Pielonefrite.";
  }
  
  const prompt = `
    Gere exatamente ${count} casos clínicos distintos focados na bactéria: ${bacteria}.
    
    CONTEXTO CLÍNICO OBRIGATÓRIO: ${contextDescription}.
    
    Detalhes da bactéria (Baseado em literatura médica e dados fornecidos):
    - Morfologia: ${bacteriaInfo.morphology}
    - Epidemiologia: ${bacteriaInfo.epidemiology}
    - Virulência: ${bacteriaInfo.virulenceFactors}
    - Manifestações: ${bacteriaInfo.clinicalManifestations}
    - Tratamento Padrão: ${bacteriaInfo.treatment}

    Diretrizes Específicas:
    ${focusInstructions}
    
    Se a bactéria for E. coli, S. agalactiae ou outras que causam múltiplas doenças, o quadro clínico DEVE ser estritamente ${category}.
    
    A resposta DEVE ser um array JSON.
  `;

  try {
    // Using gemini-2.5-flash-lite for fast response generation
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-lite',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING, description: "Unique ID" },
              title: { type: Type.STRING, description: "Catchy title in Portuguese" },
              patientProfile: { type: Type.STRING, description: "Age, gender, comorbidities" },
              symptoms: { type: Type.STRING, description: "History of Present Illness" },
              physicalExam: { type: Type.STRING, description: "Physical findings (include LCR/CSF if CNS, Urine if ITU)" },
              question: { type: Type.STRING, description: "Question for the student" },
              diagnosis: { type: Type.STRING, description: "Diagnosis" },
              treatment: { type: Type.STRING, description: "Treatment" },
              explanation: { type: Type.STRING, description: "Explanation" },
            },
            required: ["id", "title", "patientProfile", "symptoms", "physicalExam", "question", "diagnosis", "treatment", "explanation"],
          },
        },
      },
    });

    if (response.text) {
      const data = JSON.parse(response.text);
      return data as ClinicalCase[];
    }
    return [];
  } catch (error) {
    console.error("Error generating cases:", error);
    throw error;
  }
};

export const generateMixedQuizQuestion = async (): Promise<AIQuizChallengeData | null> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) return null;

  const ai = new GoogleGenAI({ apiKey });

  const prompt = `
    Crie um Desafio Clínico de Microbiologia Avançado.
    
    Instruções:
    1. Escolha aleatoriamente UM sistema: Respiratório Alto, Respiratório Baixo, SNC (Meningite) ou ITU.
    2. Escolha aleatoriamente UMA bactéria patogênica relevante para esse sistema (ex: Pneumococo, Meningococo, E. coli, S. pyogenes, etc).
    3. Crie um caso clínico detalhado e realista.
    4. Gere 4 opções de resposta. Cada opção deve conter o trio: Diagnóstico + Agente Etiológico + Tratamento.
    5. Apenas UMA opção deve ser a correta.
    6. As outras 3 opções (distratores) devem ser plausíveis (diagnósticos diferenciais comuns), mas incorretas (seja pelo agente, ou pelo tratamento errado para o agente, ou diagnóstico errado).
    
    Responda no formato JSON.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash', // Flash is smarter for logic distractor generation than lite
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: "Título do Caso" },
            patientProfile: { type: Type.STRING, description: "Ex: Mulher, 35 anos, diabética" },
            caseDescription: { type: Type.STRING, description: "História clínica e sintomas" },
            physicalExam: { type: Type.STRING, description: "Achados do exame físico e exames complementares (se houver)" },
            options: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  diagnosis: { type: Type.STRING, description: "Diagnóstico Sindrômico" },
                  pathogen: { type: Type.STRING, description: "Bactéria causadora" },
                  treatment: { type: Type.STRING, description: "Antibiótico de escolha" },
                  isCorrect: { type: Type.BOOLEAN }
                },
                required: ["id", "diagnosis", "pathogen", "treatment", "isCorrect"]
              }
            },
            explanation: { type: Type.STRING, description: "Explicação detalhada do porquê a correta é correta e as outras não." }
          },
          required: ["title", "patientProfile", "caseDescription", "physicalExam", "options", "explanation"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as AIQuizChallengeData;
    }
    return null;

  } catch (error) {
    console.error("Error generating quiz:", error);
    throw error;
  }
};

export const askBacteriaBot = async (
  bacteria: BacteriaType,
  question: string,
  useThinking: boolean = false
): Promise<string> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) return "Erro: Chave API não configurada.";

  // Initialize client inside the function to ensure the latest API Key is used
  const ai = new GoogleGenAI({ apiKey });

  const info = BACTERIA_DATA[bacteria];

  const prompt = `
    Você é um assistente especialista em microbiologia clínica.
    O aluno está estudando a bactéria: "${info.name}".
    
    CONTEXTO (DADOS FORNECIDOS):
    - Morfologia: ${info.morphology}
    - Epidemiologia: ${info.epidemiology}
    - Fatores de Virulência: ${info.virulenceFactors}
    - Manifestações Clínicas: ${info.clinicalManifestations}
    - Complicações: ${info.complications}
    - Diagnóstico: ${info.diagnosis || 'Cultivo padrão'}
    - Tratamento: ${info.treatment}
    - Classificação: ${info.classification || 'N/A'}

    PERGUNTA DO ALUNO: "${question}"

    INSTRUÇÕES:
    1. Responda de forma direta, educativa e baseada estritamente nos dados fornecidos acima e em conhecimento médico geral confiável se houver lacunas.
    2. Se a pergunta fugir do tema microbiologia/medicina, redirecione o aluno.
    3. Responda em Português.
    4. Seja conciso (máximo 3 parágrafos).
  `;

  try {
    // Use gemini-3-pro-preview with thinking budget if useThinking is true (Complex/Reasoning mode)
    // Use gemini-2.5-flash-lite if useThinking is false (Fast mode)
    const model = useThinking ? 'gemini-3-pro-preview' : 'gemini-2.5-flash-lite';
    
    const config = useThinking ? {
      thinkingConfig: { thinkingBudget: 32768 }
    } : undefined;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: config
    });
    return response.text || "Sem resposta.";
  } catch (error) {
    console.error("Chat error:", error);
    return "Desculpe, tive um problema ao conectar com o servidor. Verifique sua chave API.";
  }
};
