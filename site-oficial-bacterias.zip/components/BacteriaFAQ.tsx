
import React, { useState } from 'react';
import { BacteriaType } from '../types';
import { BACTERIA_FAQS } from '../constants';

interface BacteriaFAQProps {
  bacteria: BacteriaType;
}

const BacteriaFAQ: React.FC<BacteriaFAQProps> = ({ bacteria }) => {
  const faqs = BACTERIA_FAQS[bacteria] || [];
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="mt-8 bg-slate-50 rounded-xl border border-slate-200 overflow-hidden flex flex-col">
      <div className="bg-slate-800 p-4 flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-white">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.75M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9 5.25h.008v.008H12v-.008z" />
          </svg>
        </div>
        <div>
          <h3 className="text-white font-bold text-sm">Perguntas Frequentes</h3>
          <p className="text-slate-400 text-xs">Dúvidas comuns sobre {bacteria}</p>
        </div>
      </div>

      <div className="p-4 space-y-3">
        {faqs.length > 0 ? (
          faqs.map((faq, index) => (
            <div key={index} className="border border-slate-200 rounded-lg bg-white overflow-hidden shadow-sm transition-all">
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full text-left px-4 py-3 flex justify-between items-center bg-white hover:bg-slate-50 transition-colors"
              >
                <span className="font-semibold text-slate-800 text-sm">{faq.question}</span>
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  strokeWidth={2} 
                  stroke="currentColor" 
                  className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${openIndex === index ? 'rotate-180' : ''}`}
                >
                  <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
                </svg>
              </button>
              {openIndex === index && (
                <div className="px-4 py-3 bg-slate-50 border-t border-slate-100 text-sm text-slate-600 leading-relaxed animate-fade-in">
                  {faq.answer}
                </div>
              )}
            </div>
          ))
        ) : (
          <div className="text-center p-6 text-slate-400 text-sm">
            Nenhuma pergunta frequente cadastrada para este patógeno.
          </div>
        )}
      </div>
    </div>
  );
};

export default BacteriaFAQ;
