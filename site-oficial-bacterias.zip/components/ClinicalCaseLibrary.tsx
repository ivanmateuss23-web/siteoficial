
import React, { useState } from 'react';
import { BacteriaType, ClinicalCase, ClinicalCategory } from '../types';
import { STATIC_CASES } from '../constants';
import CaseCard from './CaseCard';

const ClinicalCaseLibrary: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<ClinicalCategory>('UPPER');
  const [selectedBacteria, setSelectedBacteria] = useState<BacteriaType | ''>('');
  
  // Mapping categories to bacteria options
  const bacteriaOptions: Record<ClinicalCategory, BacteriaType[]> = {
    UPPER: [
      BacteriaType.S_PYOGENES,
      BacteriaType.S_PNEUMONIAE,
      BacteriaType.H_INFLUENZAE,
      BacteriaType.M_CATARRHALIS
    ],
    LOWER: [
      BacteriaType.S_PNEUMONIAE,
      BacteriaType.H_INFLUENZAE,
      BacteriaType.S_AUREUS,
      BacteriaType.M_PNEUMONIAE,
      BacteriaType.C_PNEUMONIAE,
      BacteriaType.L_PNEUMOPHILA
    ],
    CNS: [
      BacteriaType.S_PNEUMONIAE,
      BacteriaType.N_MENINGITIDIS,
      BacteriaType.S_AGALACTIAE,
      BacteriaType.L_MONOCYTOGENES,
      BacteriaType.H_INFLUENZAE,
      BacteriaType.E_COLI
    ],
    ITU: [
      BacteriaType.E_COLI,
      BacteriaType.K_PNEUMONIAE,
      BacteriaType.P_MIRABILIS,
      BacteriaType.E_FAECALIS,
      BacteriaType.P_AERUGINOSA,
      BacteriaType.S_SAPROPHYTICUS,
      BacteriaType.S_AGALACTIAE
    ]
  };

  const getThemeColor = () => {
    if (selectedCategory === 'UPPER') return 'emerald';
    if (selectedCategory === 'LOWER') return 'blue';
    if (selectedCategory === 'CNS') return 'purple';
    return 'amber';
  };
  const theme = getThemeColor();

  const cases = selectedBacteria ? (STATIC_CASES[selectedBacteria as BacteriaType] || []) : [];

  return (
    <div className="flex-1 p-4 md:p-8 overflow-y-auto custom-scrollbar bg-slate-50 h-full">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 mb-8">
          <div className="text-center mb-8">
            <h2 className={`text-3xl font-bold mb-2 text-${theme}-900`}>Banco de Casos Clínicos</h2>
            <p className="text-slate-600">Explore casos pré-definidos para estudo dirigido.</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-6">
            {/* Context Selector */}
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 uppercase tracking-wide">Contexto Clínico</label>
              <div className="grid grid-cols-2 gap-2">
                {(['UPPER', 'LOWER', 'CNS', 'ITU'] as ClinicalCategory[]).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => {
                        setSelectedCategory(cat);
                        setSelectedBacteria(''); 
                    }}
                    className={`py-3 px-4 rounded-lg text-sm font-semibold transition-all border-2
                      ${selectedCategory === cat 
                        ? `border-${theme}-500 bg-${theme}-50 text-${theme}-700 shadow-sm` 
                        : 'border-slate-100 bg-slate-50 text-slate-500 hover:border-slate-300'}`}
                  >
                    {cat === 'UPPER' ? 'Vias Altas' : cat === 'LOWER' ? 'Vias Baixas' : cat === 'CNS' ? 'Sist. Nervoso' : 'Trato Urinário'}
                  </button>
                ))}
              </div>
            </div>

            {/* Bacteria Selector */}
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 uppercase tracking-wide">Patógeno Alvo</label>
              <select
                value={selectedBacteria}
                onChange={(e) => setSelectedBacteria(e.target.value as BacteriaType)}
                className={`w-full p-3 rounded-lg border-2 border-slate-200 bg-slate-50 text-slate-700 font-medium focus:outline-none focus:border-${theme}-500 transition-colors`}
              >
                <option value="" disabled>Selecione uma bactéria...</option>
                {bacteriaOptions[selectedCategory].map((b) => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {selectedBacteria && cases.length === 0 && (
           <div className="text-center p-10 text-slate-400">
             <p>Nenhum caso cadastrado para esta bactéria neste momento.</p>
           </div>
        )}

        {cases.length > 0 && (
          <div className="space-y-8 animate-fade-in">
            <h3 className="text-xl font-bold text-slate-700 border-b pb-2 mb-4">Casos Disponíveis:</h3>
            {cases.map((clinicalCase, index) => (
              <CaseCard 
                key={clinicalCase.id || index} 
                clinicalCase={clinicalCase} 
                index={index} 
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ClinicalCaseLibrary;
