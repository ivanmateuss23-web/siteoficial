import React, { useState } from 'react';
import { ClinicalCase } from '../types';

interface CaseCardProps {
  clinicalCase: ClinicalCase;
  index: number;
}

const CaseCard: React.FC<CaseCardProps> = ({ clinicalCase, index }) => {
  const [isRevealed, setIsRevealed] = useState(false);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-8 transition-all hover:shadow-md">
      {/* Case Header */}
      <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <span className="flex items-center justify-center w-8 h-8 rounded-full bg-emerald-600 text-white font-bold text-sm">
            #{index + 1}
          </span>
          <h3 className="text-lg font-semibold text-slate-800">{clinicalCase.title}</h3>
        </div>
        <span className="text-xs font-medium px-2 py-1 bg-slate-200 text-slate-600 rounded">
          {clinicalCase.patientProfile}
        </span>
      </div>

      {/* Case Content */}
      <div className="p-6">
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-emerald-700 uppercase tracking-wide flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
              Anamnese / Sintomas
            </h4>
            <p className="text-slate-600 leading-relaxed text-sm md:text-base">{clinicalCase.symptoms}</p>
          </div>
          <div className="space-y-2">
             <h4 className="text-sm font-bold text-emerald-700 uppercase tracking-wide flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
              Exame Físico
            </h4>
            <p className="text-slate-600 leading-relaxed text-sm md:text-base">{clinicalCase.physicalExam}</p>
          </div>
        </div>

        <div className="bg-amber-50 border-l-4 border-amber-400 p-4 mb-6 rounded-r-md">
          <h4 className="text-amber-900 font-bold mb-1">Desafio Clínico</h4>
          <p className="text-amber-800">{clinicalCase.question}</p>
        </div>

        {/* Reveal Interaction */}
        {!isRevealed ? (
          <button
            onClick={() => setIsRevealed(true)}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg shadow-sm transition-colors flex items-center justify-center gap-2"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            Revelar Diagnóstico e Conduta
          </button>
        ) : (
          <div className="animate-fade-in bg-slate-800 text-slate-100 rounded-lg p-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
               <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
            </div>
            
            <div className="relative z-10 space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                 <div>
                    <h5 className="text-emerald-400 font-bold text-sm uppercase mb-1">Diagnóstico</h5>
                    <p className="text-lg font-semibold">{clinicalCase.diagnosis}</p>
                 </div>
                 <div>
                    <h5 className="text-emerald-400 font-bold text-sm uppercase mb-1">Tratamento</h5>
                    <p className="text-base">{clinicalCase.treatment}</p>
                 </div>
              </div>
              <div className="pt-4 border-t border-slate-700">
                <h5 className="text-emerald-400 font-bold text-sm uppercase mb-2">Explicação Clínica</h5>
                <p className="text-slate-300 text-sm leading-relaxed">{clinicalCase.explanation}</p>
              </div>
            </div>
            
            <button 
              onClick={(e) => {
                e.preventDefault();
                setIsRevealed(false);
              }}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
              title="Hide"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CaseCard;