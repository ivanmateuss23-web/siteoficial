import React from 'react';
import { BacteriaType, ClinicalCategory } from '../types';
import { BACTERIA_DATA } from '../constants';

interface BacteriaSelectorProps {
  selectedCategory: ClinicalCategory;
  onSelectCategory: (category: ClinicalCategory) => void;
  selectedBacteria: BacteriaType | null;
  onSelectBacteria: (bacteria: BacteriaType) => void;
}

const BacteriaSelector: React.FC<BacteriaSelectorProps> = ({ 
  selectedCategory, 
  onSelectCategory,
  selectedBacteria, 
  onSelectBacteria 
}) => {
  
  const upperBacteria = [
    BacteriaType.S_PYOGENES,
    BacteriaType.S_PNEUMONIAE,
    BacteriaType.H_INFLUENZAE,
    BacteriaType.M_CATARRHALIS
  ];

  const lowerBacteria = [
    BacteriaType.S_PNEUMONIAE,
    BacteriaType.H_INFLUENZAE,
    BacteriaType.S_AUREUS,
    BacteriaType.M_PNEUMONIAE,
    BacteriaType.C_PNEUMONIAE,
    BacteriaType.L_PNEUMOPHILA
  ];

  const cnsBacteria = [
    BacteriaType.S_PNEUMONIAE,
    BacteriaType.N_MENINGITIDIS,
    BacteriaType.S_AGALACTIAE,
    BacteriaType.L_MONOCYTOGENES,
    BacteriaType.H_INFLUENZAE,
    BacteriaType.E_COLI
  ];

  const ituBacteria = [
    BacteriaType.E_COLI,
    BacteriaType.K_PNEUMONIAE,
    BacteriaType.P_MIRABILIS,
    BacteriaType.E_FAECALIS,
    BacteriaType.P_AERUGINOSA,
    BacteriaType.S_SAPROPHYTICUS,
    BacteriaType.S_AGALACTIAE
  ];

  let currentList: BacteriaType[] = [];
  let themeColor = "";
  let themeHover = "";
  
  if (selectedCategory === 'UPPER') {
    currentList = upperBacteria;
    themeColor = "bg-emerald-900";
    themeHover = "hover:bg-emerald-800/50";
  } else if (selectedCategory === 'LOWER') {
    currentList = lowerBacteria;
    themeColor = "bg-slate-900";
    themeHover = "hover:bg-blue-800/50";
  } else if (selectedCategory === 'CNS') {
    currentList = cnsBacteria;
    themeColor = "bg-purple-900";
    themeHover = "hover:bg-purple-800/50";
  } else {
    // ITU
    currentList = ituBacteria;
    themeColor = "bg-amber-900";
    themeHover = "hover:bg-amber-800/50";
  }

  return (
    <div className={`w-full md:w-72 ${themeColor} text-white flex-shrink-0 flex flex-col h-full min-h-[400px] md:min-h-screen shadow-2xl z-10 transition-colors duration-500`}>
      <div className="p-6 border-b border-white/10 bg-black/20">
        <div className="flex items-center gap-2 mb-4">
          <div className="p-2 bg-white/10 rounded-lg">
             <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-white">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
            </svg>
          </div>
          <h1 className="text-xl font-bold tracking-tight">Conteúdo</h1>
        </div>
        
        {/* Category Tabs */}
        <div className="flex bg-black/30 p-1 rounded-lg gap-1">
          <button 
            onClick={() => onSelectCategory('UPPER')}
            className={`flex-1 text-[10px] font-bold py-2 rounded-md transition-all duration-200 ${selectedCategory === 'UPPER' ? 'bg-emerald-600 text-white shadow-sm' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
          >
            ALTAS
          </button>
          <button 
            onClick={() => onSelectCategory('LOWER')}
            className={`flex-1 text-[10px] font-bold py-2 rounded-md transition-all duration-200 ${selectedCategory === 'LOWER' ? 'bg-blue-600 text-white shadow-sm' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
          >
            BAIXAS
          </button>
          <button 
            onClick={() => onSelectCategory('CNS')}
            className={`flex-1 text-[10px] font-bold py-2 rounded-md transition-all duration-200 ${selectedCategory === 'CNS' ? 'bg-purple-600 text-white shadow-sm' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
          >
            SNC
          </button>
          <button 
            onClick={() => onSelectCategory('ITU')}
            className={`flex-1 text-[10px] font-bold py-2 rounded-md transition-all duration-200 ${selectedCategory === 'ITU' ? 'bg-amber-600 text-white shadow-sm' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
          >
            ITU
          </button>
        </div>
      </div>
      
      <nav className="flex-1 overflow-y-auto p-4 space-y-1 custom-scrollbar">
        <p className="text-[10px] text-white/50 font-bold uppercase mb-3 px-2 tracking-widest">
          {selectedCategory === 'UPPER' && 'Patógenos - Trato Superior'}
          {selectedCategory === 'LOWER' && 'Patógenos - Trato Inferior'}
          {selectedCategory === 'CNS' && 'Patógenos - Sistema Nervoso'}
          {selectedCategory === 'ITU' && 'Patógenos - Trato Urinário'}
        </p>
        
        {currentList.map((bacteria) => (
          <button
            key={bacteria}
            onClick={() => onSelectBacteria(bacteria)}
            className={`w-full text-left px-4 py-3 rounded-xl text-sm transition-all duration-200 border border-transparent group relative overflow-hidden
              ${selectedBacteria === bacteria 
                ? `bg-gradient-to-r ${selectedCategory === 'CNS' ? 'from-purple-600 to-purple-500' : selectedCategory === 'LOWER' ? 'from-blue-600 to-blue-500' : selectedCategory === 'ITU' ? 'from-amber-600 to-amber-500' : 'from-emerald-600 to-emerald-500'} text-white shadow-lg font-medium translate-x-1` 
                : `${themeHover} text-emerald-100 hover:border-white/10`
              }`}
          >
            <span className="relative z-10">{bacteria}</span>
            {selectedBacteria === bacteria && (
              <span className="block text-[10px] text-emerald-100 mt-1 font-normal opacity-90 relative z-10">
                 {selectedCategory === 'CNS' 
                  ? 'Meningite / Sepse'
                  : selectedCategory === 'ITU' 
                    ? 'Cistite / Pielonefrite'
                    : selectedCategory === 'LOWER'
                      ? 'Pneumonia / Bronquite'
                      : BACTERIA_DATA[bacteria].clinicalManifestations.split(',')[0]}
              </span>
            )}
          </button>
        ))}
      </nav>
    </div>
  );
};

export default BacteriaSelector;