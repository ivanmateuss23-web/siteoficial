
import React, { useState } from 'react';
import { QuizCategory } from '../types';
import { QUIZ_DATA } from '../constants';
import QuestionCard from './QuestionCard';

const QuizModule: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<QuizCategory>('UPPER');

  const currentTopic = QUIZ_DATA.find(q => q.id === activeCategory);

  const getThemeColor = (cat: QuizCategory) => {
    switch (cat) {
      case 'UPPER': return 'emerald';
      case 'LOWER': return 'blue';
      case 'CNS': return 'purple';
      case 'ITU': return 'amber';
      case 'ANTIMICROBIALS': return 'teal';
      default: return 'slate';
    }
  };

  const themeColor = getThemeColor(activeCategory);

  return (
    <div className="flex flex-col md:flex-row h-[calc(100vh-60px)] bg-slate-50 font-sans">
      {/* Quiz Sidebar */}
      <div className={`w-full md:w-72 bg-${themeColor}-900 text-white flex-shrink-0 flex flex-col md:h-full shadow-2xl z-10 transition-colors duration-500`}>
        <div className="p-6 border-b border-white/10 bg-black/20">
          <h2 className="text-xl font-bold tracking-tight mb-1">Questionários</h2>
          <p className="text-xs text-white/60">Atividades de fixação</p>
        </div>
        
        <nav className="flex-1 overflow-y-auto p-4 space-y-2 custom-scrollbar">
          {QUIZ_DATA.map((topic) => {
            const topicTheme = getThemeColor(topic.id);
            const isActive = activeCategory === topic.id;
            
            return (
              <button
                key={topic.id}
                onClick={() => setActiveCategory(topic.id)}
                className={`w-full text-left px-4 py-3 rounded-xl text-sm transition-all duration-200 border border-transparent group
                  ${isActive 
                    ? `bg-white/10 border-white/20 shadow-lg font-medium translate-x-1` 
                    : `text-white/70 hover:bg-white/5 hover:text-white`
                  }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full bg-${topicTheme}-400 shadow-sm transition-transform group-hover:scale-110`}></div>
                  <span className="font-medium">{topic.id === 'ANTIMICROBIALS' ? 'Antimicrobianos' : topic.id === 'UPPER' ? 'Respiratório Alto' : topic.id === 'LOWER' ? 'Respiratório Baixo' : topic.id === 'CNS' ? 'Sistema Nervoso' : 'Trato Urinário'}</span>
                </div>
              </button>
            );
          })}
        </nav>
        
        <div className="p-4 bg-black/20 text-xs text-white/40 border-t border-white/5">
           20 Questões • Alternadas
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto custom-scrollbar bg-slate-100/50">
        <div className="max-w-3xl mx-auto pb-12">
          <div className={`mb-8 p-8 rounded-2xl bg-white border-l-4 border-${themeColor}-500 shadow-sm`}>
            <h1 className={`text-3xl font-bold text-${themeColor}-900 mb-2`}>{currentTopic?.title}</h1>
            <p className="text-slate-600 text-lg">{currentTopic?.description}</p>
          </div>

          <div className="space-y-8">
            {currentTopic?.questions.map((q, idx) => (
              <QuestionCard 
                key={q.id} 
                question={q} 
                index={idx} 
                themeColor={themeColor} 
              />
            ))}
          </div>
          
          <div className="mt-12 p-8 text-center bg-white rounded-xl border border-slate-200 shadow-sm">
            <div className={`w-16 h-16 rounded-full bg-${themeColor}-100 text-${themeColor}-600 mx-auto flex items-center justify-center mb-4`}>
               <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
            <h3 className="text-xl font-bold text-slate-800 mb-2">Atividade Concluída!</h3>
            <p className="text-slate-500">Você finalizou as questões deste módulo.</p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default QuizModule;
