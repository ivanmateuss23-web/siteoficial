
import React, { useState, useEffect } from 'react';
import { generateMixedQuizQuestion } from '../services/geminiService';
import { AIQuizChallengeData, AIQuizOption } from '../types';

const AIQuizChallenge: React.FC = () => {
  const [data, setData] = useState<AIQuizChallengeData | null>(null);
  const [loading, setLoading] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const loadNewQuestion = async () => {
    setLoading(true);
    setError(null);
    setSelectedOption(null);
    setData(null);
    try {
      const result = await generateMixedQuizQuestion();
      if (result) {
        setData(result);
      } else {
        setError("Não foi possível gerar um caso. Tente novamente.");
      }
    } catch (e) {
      setError("Erro de conexão ao gerar o desafio.");
    } finally {
      setLoading(false);
    }
  };

  // Load first question on mount
  useEffect(() => {
    loadNewQuestion();
  }, []);

  const handleOptionClick = (option: AIQuizOption) => {
    if (selectedOption) return; // Prevent changing answer
    setSelectedOption(option.id);
    
    if (option.isCorrect) {
      setScore(s => s + 100);
      setStreak(s => s + 1);
    } else {
      setStreak(0);
    }
  };

  const getOptionStyle = (option: AIQuizOption) => {
    if (!selectedOption) return "bg-white border-slate-200 hover:border-indigo-400 hover:shadow-md cursor-pointer";
    
    if (option.isCorrect) {
      return "bg-emerald-50 border-emerald-500 ring-1 ring-emerald-500 shadow-md"; // Always show correct answer green
    }
    
    if (selectedOption === option.id && !option.isCorrect) {
      return "bg-red-50 border-red-500 ring-1 ring-red-500 opacity-100"; // Show selected wrong answer red
    }

    return "bg-slate-50 border-slate-200 opacity-50 cursor-not-allowed"; // Dim others
  };

  return (
    <div className="flex-1 overflow-y-auto bg-slate-100 p-4 md:p-8 custom-scrollbar">
      <div className="max-w-4xl mx-auto">
        
        {/* Header / Scoreboard */}
        <div className="flex justify-between items-center mb-6 bg-white p-4 rounded-xl shadow-sm border border-slate-200">
          <div>
            <h1 className="text-2xl font-bold text-indigo-900 flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 text-indigo-600">
                <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 18.75h-9m9 0a3 3 0 013 3h-15a3 3 0 013-3m9 0v-3.375c0-.621-.504-1.125-1.125-1.125h-.871M7.5 18.75v-3.375c0-.621.504-1.125 1.125-1.125h.872m5.007 0H9.497m5.007 0V5.625a2.25 2.25 0 00-2.25-2.25h-1.5a2.25 2.25 0 00-2.25 2.25v7.5" />
              </svg>
              Desafio Clínico Global
            </h1>
            <p className="text-slate-500 text-sm">Diagnóstico • Patógeno • Tratamento</p>
          </div>
          <div className="flex gap-4">
             <div className="text-center">
                <span className="block text-xs text-slate-400 uppercase font-bold">Pontuação</span>
                <span className="text-2xl font-black text-indigo-600">{score}</span>
             </div>
             <div className="text-center">
                <span className="block text-xs text-slate-400 uppercase font-bold">Sequência</span>
                <span className="text-2xl font-black text-emerald-500 flex items-center justify-center gap-1">
                  {streak} <span className="text-base">🔥</span>
                </span>
             </div>
          </div>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center h-96 space-y-6">
            <div className="relative w-20 h-20">
              <div className="absolute top-0 left-0 w-full h-full border-4 border-indigo-200 rounded-full"></div>
              <div className="absolute top-0 left-0 w-full h-full border-4 border-indigo-600 rounded-full border-t-transparent animate-spin"></div>
            </div>
            <p className="text-indigo-800 font-medium animate-pulse">A IA está gerando um caso clínico desafiador...</p>
          </div>
        ) : error ? (
           <div className="text-center py-12">
             <p className="text-red-500 mb-4">{error}</p>
             <button onClick={loadNewQuestion} className="bg-indigo-600 text-white px-6 py-2 rounded-lg">Tentar Novamente</button>
           </div>
        ) : data ? (
          <div className="animate-fade-in space-y-6 pb-12">
            
            {/* Clinical Case Card */}
            <div className="bg-white rounded-2xl shadow-md border-t-4 border-indigo-500 overflow-hidden">
              <div className="p-6 md:p-8 space-y-6">
                <div className="flex justify-between items-start">
                  <h2 className="text-2xl font-bold text-slate-800 leading-tight">{data.title}</h2>
                  <span className="bg-indigo-100 text-indigo-800 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide">Caso Aleatório</span>
                </div>
                
                <div className="bg-slate-50 p-4 rounded-lg border-l-4 border-slate-300">
                  <p className="text-slate-600 font-medium">{data.patientProfile}</p>
                </div>

                <div className="space-y-4">
                   <div>
                     <h3 className="text-sm font-bold text-indigo-600 uppercase mb-1 flex items-center gap-2">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                        História Clínica
                     </h3>
                     <p className="text-slate-700 leading-relaxed">{data.caseDescription}</p>
                   </div>
                   <div>
                     <h3 className="text-sm font-bold text-indigo-600 uppercase mb-1 flex items-center gap-2">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                        Exame Físico / Complementar
                     </h3>
                     <p className="text-slate-700 leading-relaxed">{data.physicalExam}</p>
                   </div>
                </div>
              </div>
            </div>

            {/* Question Prompt */}
            <div className="text-center my-4">
              <h3 className="text-lg font-bold text-slate-700">Qual a melhor conduta diagnóstica e terapêutica?</h3>
              <p className="text-sm text-slate-500">Selecione a combinação correta de Diagnóstico + Patógeno + Tratamento</p>
            </div>

            {/* Options Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {data.options.map((option) => (
                <button
                  key={option.id}
                  onClick={() => handleOptionClick(option)}
                  disabled={selectedOption !== null}
                  className={`p-5 rounded-xl border-2 text-left transition-all relative overflow-hidden group ${getOptionStyle(option)}`}
                >
                  <div className="relative z-10 space-y-2">
                    <div className="flex items-start gap-2">
                      <span className="font-bold text-slate-400 text-lg group-hover:text-slate-500 transition-colors">{option.id})</span>
                      <div>
                        <div className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-1">Diagnóstico</div>
                        <div className="font-bold text-slate-800 mb-2">{option.diagnosis}</div>
                        
                        <div className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-1">Patógeno</div>
                        <div className="font-medium text-slate-700 mb-2 italic">{option.pathogen}</div>
                        
                        <div className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-1">Tratamento</div>
                        <div className="font-medium text-slate-700">{option.treatment}</div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Status Icons */}
                  {selectedOption && (
                    <div className="absolute top-4 right-4">
                      {option.isCorrect ? (
                        <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
                           <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                        </div>
                      ) : selectedOption === option.id ? (
                        <div className="w-8 h-8 rounded-full bg-red-100 text-red-600 flex items-center justify-center">
                           <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                        </div>
                      ) : null}
                    </div>
                  )}
                </button>
              ))}
            </div>

            {/* Explanation & Next Button */}
            {selectedOption && (
              <div className="bg-slate-800 rounded-xl p-6 md:p-8 text-white animate-fade-in mt-6 shadow-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-12 opacity-5">
                   <svg className="w-64 h-64" fill="currentColor" viewBox="0 0 24 24"><path d="M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.75M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9 5.25h.008v.008H12v-.008z" /></svg>
                </div>
                <div className="relative z-10">
                   <h3 className="text-emerald-400 font-bold text-lg uppercase mb-3 flex items-center gap-2">
                     <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                     Explicação do Professor
                   </h3>
                   <div className="prose prose-invert max-w-none text-slate-300 leading-relaxed">
                     {data.explanation}
                   </div>
                   
                   <div className="mt-8 flex justify-end">
                     <button
                       onClick={loadNewQuestion}
                       className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 px-8 rounded-lg shadow-lg transition-transform transform active:scale-95 flex items-center gap-2"
                     >
                       Próximo Desafio
                       <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
                     </button>
                   </div>
                </div>
              </div>
            )}
            
          </div>
        ) : null}
      </div>
    </div>
  );
};

export default AIQuizChallenge;
