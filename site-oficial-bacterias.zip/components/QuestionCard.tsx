
import React, { useState } from 'react';
import { QuizQuestion } from '../types';

interface QuestionCardProps {
  question: QuizQuestion;
  index: number;
  themeColor: string;
}

const QuestionCard: React.FC<QuestionCardProps> = ({ question, index, themeColor }) => {
  const [showAnswer, setShowAnswer] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [textAnswer, setTextAnswer] = useState('');

  const isMultipleChoice = question.type === 'multiple-choice';

  const getThemeStyles = () => {
    switch (themeColor) {
      case 'emerald': return { bg: 'bg-emerald-50', text: 'text-emerald-800', border: 'border-emerald-200', btn: 'bg-emerald-600 hover:bg-emerald-700', active: 'ring-emerald-500' };
      case 'blue': return { bg: 'bg-blue-50', text: 'text-blue-800', border: 'border-blue-200', btn: 'bg-blue-600 hover:bg-blue-700', active: 'ring-blue-500' };
      case 'purple': return { bg: 'bg-purple-50', text: 'text-purple-800', border: 'border-purple-200', btn: 'bg-purple-600 hover:bg-purple-700', active: 'ring-purple-500' };
      case 'amber': return { bg: 'bg-amber-50', text: 'text-amber-800', border: 'border-amber-200', btn: 'bg-amber-600 hover:bg-amber-700', active: 'ring-amber-500' };
      case 'teal': return { bg: 'bg-teal-50', text: 'text-teal-800', border: 'border-teal-200', btn: 'bg-teal-600 hover:bg-teal-700', active: 'ring-teal-500' };
      default: return { bg: 'bg-slate-50', text: 'text-slate-800', border: 'border-slate-200', btn: 'bg-slate-600 hover:bg-slate-700', active: 'ring-slate-500' };
    }
  };

  const styles = getThemeStyles();

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6 transition-all hover:shadow-md">
      <div className={`${styles.bg} px-6 py-4 border-b ${styles.border} flex flex-col gap-2`}>
        <div className="flex items-center gap-3">
          <span className={`flex items-center justify-center w-8 h-8 rounded-full ${styles.btn} text-white font-bold text-sm shrink-0`}>
            {index + 1}
          </span>
          {question.context && (
            <span className="text-xs font-bold uppercase tracking-wider opacity-70 border border-current px-2 py-0.5 rounded">
              {question.context}
            </span>
          )}
        </div>
        <h3 className="text-lg font-semibold text-slate-800 ml-1">{question.text}</h3>
      </div>

      <div className="p-6">
        {isMultipleChoice ? (
          <div className="space-y-3">
            {question.options?.map((option) => {
              let optionStyle = "border-slate-200 hover:bg-slate-50";
              let icon = null;

              if (showAnswer) {
                if (option.id === question.correctAnswer) {
                  optionStyle = "bg-green-100 border-green-300 ring-1 ring-green-500";
                  icon = <svg className="w-5 h-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>;
                } else if (selectedOption === option.id) {
                  optionStyle = "bg-red-50 border-red-200 ring-1 ring-red-300";
                  icon = <svg className="w-5 h-5 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>;
                } else {
                  optionStyle = "opacity-50";
                }
              } else if (selectedOption === option.id) {
                optionStyle = `bg-${themeColor}-50 border-${themeColor}-300 ring-1 ring-${themeColor}-500`;
              }

              return (
                <button
                  key={option.id}
                  onClick={() => !showAnswer && setSelectedOption(option.id)}
                  disabled={showAnswer}
                  className={`w-full text-left p-4 rounded-lg border transition-all flex items-center justify-between gap-3 ${optionStyle}`}
                >
                  <span className={`flex-1 ${showAnswer && option.id === question.correctAnswer ? 'font-bold text-green-900' : 'text-slate-700'}`}>
                    <span className="font-bold mr-2 text-slate-400">{option.id.toUpperCase()})</span>
                    {option.text}
                  </span>
                  {icon}
                </button>
              );
            })}
          </div>
        ) : (
          <div className="mb-4">
            <textarea
              className="w-full p-4 border border-slate-300 rounded-lg focus:ring-2 focus:ring-opacity-50 focus:outline-none transition-all text-slate-700 placeholder-slate-400 bg-slate-50 focus:bg-white"
              style={{ minHeight: '120px', borderColor: showAnswer ? '#cbd5e1' : undefined }}
              placeholder="Escreva sua resposta aqui..."
              value={textAnswer}
              onChange={(e) => setTextAnswer(e.target.value)}
              disabled={showAnswer}
            />
          </div>
        )}

        <div className="mt-6 pt-4 border-t border-slate-100 flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
          {!showAnswer ? (
            <button
              onClick={() => setShowAnswer(true)}
              className={`px-6 py-2.5 ${styles.btn} text-white font-semibold rounded-lg shadow-sm transition-transform active:scale-95 w-full md:w-auto text-center`}
            >
              {isMultipleChoice ? 'Confirmar Resposta' : 'Ver Gabarito'}
            </button>
          ) : (
            <div className="w-full animate-fade-in">
              <div className={`p-4 rounded-lg ${isMultipleChoice ? (selectedOption === question.correctAnswer ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200') : 'bg-slate-100 border border-slate-200'}`}>
                {isMultipleChoice ? (
                   <div className="flex items-center gap-2 mb-2">
                      {selectedOption === question.correctAnswer ? (
                        <span className="text-green-700 font-bold flex items-center gap-1">
                          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                          Correto!
                        </span>
                      ) : (
                        <span className="text-red-700 font-bold flex items-center gap-1">
                           <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                           Incorreto.
                        </span>
                      )}
                   </div>
                ) : (
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Gabarito / Resposta Esperada:</p>
                )}
                
                <p className="text-slate-800 font-medium leading-relaxed">
                  {isMultipleChoice 
                    ? question.options?.find(o => o.id === question.correctAnswer)?.text 
                    : question.correctAnswer}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default QuestionCard;
