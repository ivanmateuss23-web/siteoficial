
import React, { useState } from 'react';
import { BacteriaType } from '../types';
import { BACTERIA_DATA } from '../constants';
import BacteriaFAQ from './BacteriaFAQ';
import BacteriaChat from './BacteriaChat';

interface InfoPanelProps {
  bacteria: BacteriaType;
}

const InfoPanel: React.FC<InfoPanelProps> = ({ bacteria }) => {
  const info = BACTERIA_DATA[bacteria];
  const [activeTab, setActiveTab] = useState<'FAQ' | 'CHAT'>('FAQ');

  return (
    <div className="space-y-8 pb-12">
      <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden transition-all">
        {/* Header */}
        <div className="bg-slate-900 text-white p-6 relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-3xl font-bold tracking-tight mb-2 text-emerald-400">{info.name}</h2>
                <span className="inline-block bg-white/20 backdrop-blur-sm text-xs font-semibold px-3 py-1 rounded-full uppercase tracking-wider">
                  {info.type}
                </span>
              </div>
            </div>
          </div>
          
          {/* Background Pattern */}
          <div className="absolute top-0 right-0 p-8 opacity-5">
            <svg className="w-40 h-40" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/></svg>
          </div>
        </div>

        {/* Content Grid */}
        <div className="p-6 grid gap-8">
          
          {/* Section 1: Microbiologia & Virulência */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest border-b border-slate-200 pb-1">Morfologia & Características</h3>
              <p className="text-slate-700 font-medium leading-relaxed">{info.morphology}</p>
            </div>
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest border-b border-slate-200 pb-1">Fatores de Virulência</h3>
              <p className="text-slate-700 font-medium leading-relaxed">{info.virulenceFactors}</p>
            </div>
          </div>

          {/* Section 2: Epidemiologia */}
          <div className="bg-slate-50 p-5 rounded-lg border border-slate-100">
            <h3 className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              Epidemiologia
            </h3>
            <p className="text-slate-700 text-sm leading-relaxed">{info.epidemiology}</p>
          </div>

          {/* Section 3: Clínica */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-emerald-600 uppercase tracking-widest border-b border-emerald-100 pb-1">Manifestações Clínicas</h3>
              <p className="text-slate-700 text-sm">{info.clinicalManifestations}</p>
            </div>
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-red-600 uppercase tracking-widest border-b border-red-100 pb-1">Complicaciones</h3>
              <p className="text-slate-700 text-sm">{info.complications}</p>
            </div>
          </div>

          {/* Section 4: Gestão */}
          <div className="grid md:grid-cols-2 gap-6">
             <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
               <h3 className="text-xs font-bold text-blue-800 uppercase mb-2">Classificação / Diagnóstico</h3>
               <div className="space-y-2">
                 {info.classification && (
                   <div className="flex gap-2 text-sm">
                     <span className="font-semibold text-blue-700">Tipo:</span>
                     <span className="text-blue-900">{info.classification}</span>
                   </div>
                 )}
                 {info.diagnosis && (
                   <div className="flex flex-col gap-1 text-sm mt-2">
                     <span className="font-semibold text-blue-700">Métodos Diagnósticos:</span>
                     <span className="text-blue-900">{info.diagnosis}</span>
                   </div>
                 )}
               </div>
             </div>

             <div className="bg-emerald-50 p-4 rounded-lg border border-emerald-100">
               <h3 className="text-xs font-bold text-emerald-800 uppercase mb-2">Tratamento Recomendado</h3>
               <p className="text-sm text-emerald-900 font-medium italic">
                 "{info.treatment}"
               </p>
             </div>
          </div>

        </div>
      </div>

      {/* FAQ / Chat Section with Tabs */}
      <div className="mt-8">
        <div className="flex gap-2 mb-4 border-b border-slate-200">
          <button
            onClick={() => setActiveTab('FAQ')}
            className={`px-4 py-2 text-sm font-bold border-b-2 transition-colors ${
              activeTab === 'FAQ' 
                ? 'border-emerald-500 text-emerald-700' 
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            Perguntas Frequentes (Static)
          </button>
          <button
            onClick={() => setActiveTab('CHAT')}
            className={`px-4 py-2 text-sm font-bold border-b-2 transition-colors ${
              activeTab === 'CHAT' 
                ? 'border-purple-500 text-purple-700' 
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            Chat com IA (Gemini)
          </button>
        </div>

        {activeTab === 'FAQ' ? (
          <BacteriaFAQ bacteria={bacteria} />
        ) : (
          <div className="animate-fade-in">
            <BacteriaChat bacteria={bacteria} />
          </div>
        )}
      </div>
    </div>
  );
};

export default InfoPanel;
