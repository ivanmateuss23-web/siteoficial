
import React, { useState, useEffect, useRef } from 'react';
import { BacteriaType } from '../types';
import { askBacteriaBot } from '../services/geminiService';

interface BacteriaChatProps {
  bacteria: BacteriaType;
  className?: string;
}

interface Message {
  id: string;
  role: 'user' | 'ai';
  text: string;
}

const BacteriaChat: React.FC<BacteriaChatProps> = ({ bacteria, className = "mt-8 h-[600px] rounded-xl border border-slate-200" }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [useThinking, setUseThinking] = useState(false); // State for Thinking Mode
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Reset chat when bacteria changes
  useEffect(() => {
    setMessages([{
      id: 'welcome',
      role: 'ai',
      text: `Olá! Sou seu assistente virtual especializado em ${bacteria}. Tem alguma dúvida sobre morfologia, tratamento ou quadro clínico?`
    }]);
  }, [bacteria]);

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = { id: Date.now().toString(), role: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const responseText = await askBacteriaBot(bacteria, userMessage.text, useThinking);
      const aiMessage: Message = { 
        id: (Date.now() + 1).toString(), 
        role: 'ai', 
        text: responseText 
      };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      setMessages(prev => [...prev, { 
        id: Date.now().toString(), 
        role: 'ai', 
        text: 'Desculpe, tive um problema ao conectar com o servidor.' 
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className={`bg-slate-50 overflow-hidden flex flex-col ${className}`}>
      <div className="bg-slate-800 p-4 flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-white">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 3v1.5M4.5 8.25H3m18 0h-1.5M4.5 12h15m-15 3.75h15m-15 3.75h15M8.25 21v-1.5m7.5 1.5v-1.5m-9-1.5h10.5a2.25 2.25 0 002.25-2.25V6.75a2.25 2.25 0 00-2.25-2.25H6.75A2.25 2.25 0 004.5 6.75v10.5a2.25 2.25 0 002.25 2.25z" />
            </svg>
          </div>
          <div>
            <h3 className="text-white font-bold text-sm">IA Microbiologista</h3>
            <p className="text-slate-400 text-xs">Tire dúvidas sobre {bacteria}</p>
          </div>
        </div>
        
        {/* Thinking Mode Toggle */}
        <label className="flex items-center cursor-pointer gap-2 bg-slate-700 px-3 py-1.5 rounded-lg border border-slate-600 hover:bg-slate-600 transition-colors">
          <div className="relative">
            <input 
              type="checkbox" 
              className="sr-only" 
              checked={useThinking} 
              onChange={() => setUseThinking(!useThinking)}
            />
            <div className={`block w-8 h-5 rounded-full transition-colors ${useThinking ? 'bg-purple-500' : 'bg-slate-400'}`}></div>
            <div className={`dot absolute left-1 top-1 bg-white w-3 h-3 rounded-full transition-transform ${useThinking ? 'translate-x-3' : ''}`}></div>
          </div>
          <span className={`text-xs font-medium ${useThinking ? 'text-purple-300' : 'text-slate-300'}`}>
            {useThinking ? 'Modo Pensamento (Pro)' : 'Modo Rápido (Lite)'}
          </span>
        </label>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-100">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm shadow-sm
              ${msg.role === 'user' 
                ? 'bg-slate-700 text-white rounded-br-none' 
                : 'bg-white text-slate-800 border border-slate-200 rounded-bl-none'
              }`}
            >
              <div className="whitespace-pre-wrap">{msg.text}</div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white px-4 py-3 rounded-2xl rounded-bl-none border border-slate-200 shadow-sm flex flex-col gap-2">
              <div className="flex gap-2 items-center">
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-75"></div>
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-150"></div>
              </div>
              {useThinking && (
                <span className="text-[10px] text-purple-600 font-medium animate-pulse">
                  Pensando profundamente...
                </span>
              )}
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 bg-white border-t border-slate-200 shrink-0">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={useThinking ? "Faça uma pergunta complexa..." : "Tire uma dúvida rápida..."}
            className={`flex-1 border rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:border-transparent text-sm transition-all
              ${useThinking ? 'border-purple-200 focus:ring-purple-500 bg-purple-50/30' : 'border-slate-300 focus:ring-emerald-500'}`}
            disabled={loading}
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || loading}
            className={`px-4 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-white
              ${useThinking ? 'bg-purple-600 hover:bg-purple-700' : 'bg-emerald-600 hover:bg-emerald-700'}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default BacteriaChat;
