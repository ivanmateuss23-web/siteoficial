
import React, { useState } from 'react';

type Section = 'MORPHOLOGY' | 'STRUCTURE' | 'GRAM' | 'PHYSIOLOGY';

const GeneralBacteriology: React.FC = () => {
  const [activeSection, setActiveSection] = useState<Section>('MORPHOLOGY');

  // Interactive Content States
  const [selectedShape, setSelectedShape] = useState<'COCOS' | 'BACILOS' | 'ESPIROQUETAS'>('COCOS');
  const [selectedStructure, setSelectedStructure] = useState<string | null>(null);

  const renderSidebar = () => (
    <div className="w-full md:w-64 bg-slate-900 text-white flex-shrink-0 flex flex-col md:h-full p-4 gap-2">
      <div className="mb-4 px-2">
        <h2 className="text-xl font-bold text-cyan-400">Bacteriologia Geral</h2>
        <p className="text-xs text-slate-400">Fundamentos Essenciais</p>
      </div>
      
      <button 
        onClick={() => setActiveSection('MORPHOLOGY')}
        className={`text-left px-4 py-3 rounded-lg text-sm font-medium transition-all ${activeSection === 'MORPHOLOGY' ? 'bg-cyan-600 text-white' : 'hover:bg-white/10 text-slate-300'}`}
      >
        🔬 Morfologia Bacteriana
      </button>
      <button 
        onClick={() => setActiveSection('STRUCTURE')}
        className={`text-left px-4 py-3 rounded-lg text-sm font-medium transition-all ${activeSection === 'STRUCTURE' ? 'bg-cyan-600 text-white' : 'hover:bg-white/10 text-slate-300'}`}
      >
        🧬 Estrutura Celular
      </button>
      <button 
        onClick={() => setActiveSection('GRAM')}
        className={`text-left px-4 py-3 rounded-lg text-sm font-medium transition-all ${activeSection === 'GRAM' ? 'bg-cyan-600 text-white' : 'hover:bg-white/10 text-slate-300'}`}
      >
        🎨 Coloração de Gram
      </button>
      <button 
        onClick={() => setActiveSection('PHYSIOLOGY')}
        className={`text-left px-4 py-3 rounded-lg text-sm font-medium transition-all ${activeSection === 'PHYSIOLOGY' ? 'bg-cyan-600 text-white' : 'hover:bg-white/10 text-slate-300'}`}
      >
        🌡️ Fisiologia & Crescimento
      </button>
    </div>
  );

  const renderMorphology = () => (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
        <h2 className="text-2xl font-bold text-slate-800 mb-4 flex items-center gap-2">
          <span className="text-4xl">🦠</span> Formas e Arranjos
        </h2>
        <p className="text-slate-600 mb-6">
          As bactérias são seres unicelulares procariontes. Sua identificação começa pela forma visualizada ao microscópio.
          Selecione uma forma base para ver suas variações:
        </p>

        <div className="flex gap-4 mb-8 overflow-x-auto pb-2">
          <button 
            onClick={() => setSelectedShape('COCOS')}
            className={`flex-1 min-w-[120px] p-4 rounded-xl border-2 flex flex-col items-center gap-3 transition-all ${selectedShape === 'COCOS' ? 'border-cyan-500 bg-cyan-50 shadow-md' : 'border-slate-200 hover:border-cyan-200'}`}
          >
            <div className="w-12 h-12 rounded-full border-4 border-slate-800 bg-slate-300"></div>
            <span className="font-bold text-slate-700">Cocos</span>
            <span className="text-xs text-slate-500">Esféricos</span>
          </button>
          
          <button 
            onClick={() => setSelectedShape('BACILOS')}
            className={`flex-1 min-w-[120px] p-4 rounded-xl border-2 flex flex-col items-center gap-3 transition-all ${selectedShape === 'BACILOS' ? 'border-cyan-500 bg-cyan-50 shadow-md' : 'border-slate-200 hover:border-cyan-200'}`}
          >
            <div className="w-16 h-8 rounded-full border-4 border-slate-800 bg-slate-300"></div>
            <span className="font-bold text-slate-700">Bacilos</span>
            <span className="text-xs text-slate-500">Bastões (Varillas)</span>
          </button>

          <button 
            onClick={() => setSelectedShape('ESPIROQUETAS')}
            className={`flex-1 min-w-[120px] p-4 rounded-xl border-2 flex flex-col items-center gap-3 transition-all ${selectedShape === 'ESPIROQUETAS' ? 'border-cyan-500 bg-cyan-50 shadow-md' : 'border-slate-200 hover:border-cyan-200'}`}
          >
            <svg viewBox="0 0 100 50" className="w-16 h-10 stroke-slate-800 stroke-[4px] fill-none">
              <path d="M5 25 Q 15 5, 25 25 T 45 25 T 65 25 T 85 25" />
            </svg>
            <span className="font-bold text-slate-700">Espiroquetas</span>
            <span className="text-xs text-slate-500">Espirais</span>
          </button>
        </div>

        <div className="bg-slate-50 p-6 rounded-lg border border-slate-200">
          {selectedShape === 'COCOS' && (
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-bold text-cyan-700 text-lg mb-2">Arranjos dos Cocos</h3>
                <ul className="space-y-3">
                  <li className="flex items-center gap-3">
                    <div className="flex"><div className="w-3 h-3 rounded-full bg-cyan-600"></div><div className="w-3 h-3 rounded-full bg-cyan-600"></div></div>
                    <div>
                      <span className="font-bold block">Diplococos</span>
                      <span className="text-sm text-slate-600">Pares. Ex: <i>Pneumococo, Neisseria</i></span>
                    </div>
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="flex"><div className="w-3 h-3 rounded-full bg-cyan-600"></div><div className="w-3 h-3 rounded-full bg-cyan-600"></div><div className="w-3 h-3 rounded-full bg-cyan-600"></div><div className="w-3 h-3 rounded-full bg-cyan-600"></div></div>
                    <div>
                      <span className="font-bold block">Estreptococos</span>
                      <span className="text-sm text-slate-600">Cadeias. Ex: <i>S. pyogenes</i></span>
                    </div>
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="grid grid-cols-3 w-8"><div className="w-3 h-3 rounded-full bg-purple-600"></div><div className="w-3 h-3 rounded-full bg-purple-600"></div><div className="w-3 h-3 rounded-full bg-purple-600"></div><div className="w-3 h-3 rounded-full bg-purple-600"></div><div className="w-3 h-3 rounded-full bg-purple-600"></div></div>
                    <div>
                      <span className="font-bold block">Estafilococos</span>
                      <span className="text-sm text-slate-600">Cachos de uva. Ex: <i>S. aureus</i></span>
                    </div>
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="grid grid-cols-2 w-5"><div className="w-2 h-2 rounded-full bg-cyan-600"></div><div className="w-2 h-2 rounded-full bg-cyan-600"></div><div className="w-2 h-2 rounded-full bg-cyan-600"></div><div className="w-2 h-2 rounded-full bg-cyan-600"></div></div>
                    <div>
                      <span className="font-bold block">Tétradas / Sarcinas</span>
                      <span className="text-sm text-slate-600">Grupos de 4 ou cubos de 8.</span>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="bg-white p-4 rounded border border-slate-100 flex items-center justify-center">
                 <p className="text-center text-slate-400 italic">"Kókkos" (Grego) = Grão</p>
              </div>
            </div>
          )}

          {selectedShape === 'BACILOS' && (
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-bold text-cyan-700 text-lg mb-2">Variações dos Bacilos</h3>
                <ul className="space-y-3">
                  <li className="flex items-center gap-3">
                    <div className="w-8 h-3 bg-cyan-600 rounded-full"></div>
                    <div>
                      <span className="font-bold block">Bacilo Simples</span>
                      <span className="text-sm text-slate-600">Ex: <i>E. coli, Pseudomonas</i></span>
                    </div>
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="flex"><div className="w-6 h-3 bg-cyan-600 rounded-l-full border-r border-white"></div><div className="w-6 h-3 bg-cyan-600 rounded-r-full"></div></div>
                    <div>
                      <span className="font-bold block">Estreptobacilos</span>
                      <span className="text-sm text-slate-600">Cadeias de bacilos.</span>
                    </div>
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="w-6 h-4 bg-purple-600 rounded-full"></div>
                    <div>
                      <span className="font-bold block">Cocobacilo</span>
                      <span className="text-sm text-slate-600">Intermediário (curto e grosso). Ex: <i>Haemophilus</i></span>
                    </div>
                  </li>
                  <li className="flex items-center gap-3">
                    <svg width="30" height="15" viewBox="0 0 30 15"><path d="M0,8 Q15,0 30,8" fill="none" stroke="#0891b2" strokeWidth="3" /></svg>
                    <div>
                      <span className="font-bold block">Vibrio</span>
                      <span className="text-sm text-slate-600">Forma de vírgula. Ex: <i>Vibrio cholerae</i></span>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="bg-white p-4 rounded border border-slate-100 flex flex-col items-center justify-center text-center">
                 <p className="text-slate-400 italic mb-2">"Baculus" (Latim) = Varilla/Bastão</p>
                 <p className="text-xs text-slate-500">Arranjos curiosos: "Letras Chinesas" ou "Empalizada" (<i>Corynebacterium</i>)</p>
              </div>
            </div>
          )}

          {selectedShape === 'ESPIROQUETAS' && (
             <div className="space-y-4">
                <p className="text-slate-700">Bactérias longas, delgadas, flexíveis e helicoidais (forma de saca-rolhas).</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-white p-3 rounded border text-center">
                    <span className="font-bold block text-cyan-700">Treponema</span>
                    <span className="text-xs">Sífilis</span>
                  </div>
                  <div className="bg-white p-3 rounded border text-center">
                    <span className="font-bold block text-cyan-700">Borrelia</span>
                    <span className="text-xs">Doença de Lyme</span>
                  </div>
                  <div className="bg-white p-3 rounded border text-center">
                    <span className="font-bold block text-cyan-700">Leptospira</span>
                    <span className="text-xs">Leptospirose</span>
                  </div>
                </div>
             </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderStructure = () => {
    const structures = [
      { id: 'PARED', label: 'Pared Celular', icon: '🧱', content: 'Capa rígida de Peptidoglicano (Mureína). Dá forma à bactéria e protege contra lise osmótica. É o alvo das Penicilinas.' },
      { id: 'MEMBRANA', label: 'Membrana Plasmática', icon: '🧼', content: 'Bicamada fosfolipídica. Local de produção de energia (respiração celular) e transporte seletivo. Possui mesossomos (dobras).' },
      { id: 'GENOMA', label: 'Genoma / Nucleoide', icon: '🧬', content: 'Cromossomo único, circular, DNA dupla fita, disperso no citoplasma (sem núcleo). Pode ter Plasmídeos (DNA extra).' },
      { id: 'FLAGELO', label: 'Flagelos', icon: '🚤', content: 'Estruturas proteicas longas para locomoção (motilidade). Podem ser Monotricos (1), Lofotricos (tufo) ou Peritricos (ao redor).' },
      { id: 'FIMBRIA', label: 'Fímbrias / Pili', icon: '🪝', content: 'Curtas e numerosas. Fímbrias de A adesão (fixam no tecido) e Pili Sexual (conjugação/troca de DNA).' },
      { id: 'CAPSULA', label: 'Cápsula', icon: '💊', content: 'Camada mucosa externa de polissacarídeos. Fator de virulência CRÍTICO: Antifagocítica (o sistema imune "escorrega"). Ex: Pneumococo, Meningococo.' },
      { id: 'ESPORO', label: 'Endosporos', icon: '🛡️', content: 'Estrutura de resistência extrema formada por certas bactérias (Clostridium, Bacillus) em condições hostis. Sobrevivem a fervura e desinfetantes.' }
    ];

    return (
      <div className="space-y-6 animate-fade-in">
        <h2 className="text-2xl font-bold text-slate-800 mb-4">Estrutura Bacteriana</h2>
        <div className="grid md:grid-cols-2 gap-8">
           {/* Visual Diagram Placeholder - simplified with CSS */}
           <div className="relative h-80 bg-cyan-900 rounded-3xl flex items-center justify-center p-8 shadow-inner overflow-hidden">
              {/* Bacterium Body */}
              <div className="relative w-48 h-24 bg-cyan-100 rounded-full border-4 border-yellow-400 z-10 flex items-center justify-center">
                 <div className="absolute inset-0 bg-opacity-20 bg-grid-pattern"></div>
                 {/* DNA */}
                 <svg className="w-16 h-16 text-purple-600 animate-pulse" viewBox="0 0 100 100"><path d="M20,50 Q40,20 60,50 T100,50" fill="none" stroke="currentColor" strokeWidth="4" /></svg>
                 {/* Flagella */}
                 <div className="absolute -right-12 top-8 w-16 h-1 bg-slate-400 rotate-12"></div>
                 {/* Pili */}
                 <div className="absolute -top-2 left-10 w-1 h-3 bg-slate-500"></div>
                 <div className="absolute -bottom-2 right-10 w-1 h-3 bg-slate-500"></div>
              </div>
              {/* Capsule Halo */}
              <div className="absolute w-56 h-32 bg-white/20 rounded-full blur-sm z-0"></div>
              
              <div className="absolute bottom-4 text-white text-xs opacity-50">Clique nos itens ao lado para detalhes</div>
           </div>

           <div className="space-y-2 h-96 overflow-y-auto custom-scrollbar pr-2">
             {structures.map((s) => (
               <div key={s.id} className="collapse-group">
                 <button
                   onClick={() => setSelectedStructure(selectedStructure === s.id ? null : s.id)}
                   className={`w-full flex items-center gap-3 p-3 rounded-lg border transition-all ${selectedStructure === s.id ? 'bg-cyan-100 border-cyan-400 shadow-md' : 'bg-white border-slate-200 hover:bg-slate-50'}`}
                 >
                   <span className="text-2xl">{s.icon}</span>
                   <span className="font-bold text-slate-700">{s.label}</span>
                 </button>
                 {selectedStructure === s.id && (
                   <div className="p-3 bg-white border-x border-b border-cyan-200 rounded-b-lg text-sm text-slate-600 animate-fade-in">
                     {s.content}
                   </div>
                 )}
               </div>
             ))}
           </div>
        </div>
        
        {/* Special Note Box */}
        <div className="bg-amber-50 border-l-4 border-amber-400 p-4 rounded text-sm text-amber-900">
           <strong>Exceções Importantes:</strong> 
           <ul className="list-disc ml-5 mt-1">
             <li><strong>Mycoplasma:</strong> Não tem parede celular (não cora no Gram, resistente a penicilina).</li>
             <li><strong>Micobactérias (TB):</strong> Parede rica em lipídios/ácidos micólicos (BAAR).</li>
           </ul>
        </div>
      </div>
    );
  };

  const renderGram = () => (
    <div className="space-y-6 animate-fade-in">
      <h2 className="text-2xl font-bold text-slate-800 mb-2">Coloração de Gram</h2>
      <p className="text-slate-600 mb-6">A técnica fundamental (1884) que divide as bactérias em dois grandes grupos baseados na estrutura da parede celular.</p>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Gram Positive */}
        <div className="bg-purple-50 border-2 border-purple-200 rounded-xl p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 bg-purple-200 text-purple-800 text-xs font-bold px-2 py-1 rounded-bl">ROXO / AZUL</div>
          <h3 className="text-xl font-bold text-purple-900 mb-4">Gram Positivas (+)</h3>
          
          <div className="flex flex-col gap-2 mb-4">
            <div className="h-16 w-full bg-purple-400 rounded-md border-2 border-purple-900 flex items-center justify-center text-white font-bold shadow-sm">
               Peptidoglicano (Espesso)
            </div>
            <div className="h-4 w-full bg-yellow-200 rounded-md border border-yellow-400 opacity-80 flex items-center justify-center text-[10px]">
               Membrana Plasmática
            </div>
          </div>

          <ul className="text-sm space-y-2 text-purple-900">
            <li>✅ Parede Celular Grossa (muitas camadas)</li>
            <li>✅ Ácidos Teicoicos presentes</li>
            <li>❌ Sem Membrana Externa</li>
            <li>❌ Sem LPS (Endotoxina)</li>
            <li>🛡️ Mais sensíveis à Penicilina/Lisozima</li>
          </ul>
        </div>

        {/* Gram Negative */}
        <div className="bg-pink-50 border-2 border-pink-200 rounded-xl p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 bg-pink-200 text-pink-800 text-xs font-bold px-2 py-1 rounded-bl">ROSA / VERMELHO</div>
          <h3 className="text-xl font-bold text-pink-900 mb-4">Gram Negativas (-)</h3>
          
          <div className="flex flex-col gap-1 mb-4">
            <div className="h-6 w-full bg-pink-300 rounded-md border-2 border-pink-500 flex items-center justify-center text-xs font-bold text-white shadow-sm relative">
               Membrana Externa (LPS)
            </div>
            <div className="h-4 w-full bg-slate-200 rounded-sm flex items-center justify-center text-[8px] text-slate-500">
               Periplasma + Peptidoglicano (Fino)
            </div>
            <div className="h-4 w-full bg-yellow-200 rounded-md border border-yellow-400 opacity-80 flex items-center justify-center text-[10px]">
               Membrana Plasmática
            </div>
          </div>

          <ul className="text-sm space-y-2 text-pink-900">
            <li>✅ Membrana Externa presente (barreira extra)</li>
            <li>✅ <strong>LPS (Lipopolissacarídeo):</strong> Endotoxina potente (choque)</li>
            <li>✅ Espaço Periplásmico (enzimas degradativas)</li>
            <li>⚠️ Parede de Peptidoglicano fina</li>
            <li>🛡️ Mais resistentes a antibióticos</li>
          </ul>
        </div>
      </div>
    </div>
  );

  const renderPhysiology = () => (
    <div className="space-y-6 animate-fade-in">
      <h2 className="text-2xl font-bold text-slate-800 mb-4">Fisiologia e Crescimento</h2>
      
      {/* Oxygen */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <h3 className="font-bold text-cyan-800 text-lg mb-3 flex items-center gap-2">
          💨 Necessidade de Oxigênio
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div className="p-3 bg-slate-50 rounded border hover:bg-cyan-50 transition-colors">
            <div className="font-bold text-sm">Aeróbios Estritos</div>
            <div className="text-xs text-slate-500 mt-1">Precisam de O2 (Morrem sem).<br/><i>M. tuberculosis</i></div>
          </div>
          <div className="p-3 bg-slate-50 rounded border hover:bg-cyan-50 transition-colors">
            <div className="font-bold text-sm">Anaeróbios Estritos</div>
            <div className="text-xs text-slate-500 mt-1">O2 é tóxico.<br/><i>Clostridium</i></div>
          </div>
          <div className="p-3 bg-slate-50 rounded border hover:bg-cyan-50 transition-colors">
            <div className="font-bold text-sm">Facultativos</div>
            <div className="text-xs text-slate-500 mt-1">Preferem O2, mas vivem sem.<br/><i>E. coli, S. aureus</i></div>
          </div>
          <div className="p-3 bg-slate-50 rounded border hover:bg-cyan-50 transition-colors">
            <div className="font-bold text-sm">Microaerófilos</div>
            <div className="text-xs text-slate-500 mt-1">Precisam de pouco O2.<br/><i>H. pylori</i></div>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Temperature */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="font-bold text-orange-800 text-lg mb-3 flex items-center gap-2">
            🌡️ Temperatura
          </h3>
          <ul className="space-y-3 text-sm">
            <li className="flex justify-between items-center border-b pb-2">
              <span className="font-medium">Psicrófilos</span>
              <span className="text-blue-500 font-bold">&lt; 20°C</span>
            </li>
            <li className="flex justify-between items-center border-b pb-2 bg-orange-50 -mx-2 px-2 rounded">
              <span className="font-bold text-orange-700">Mesófilos</span>
              <span className="text-orange-600 font-bold">20°C - 45°C</span>
            </li>
            <li className="text-xs text-center text-slate-500 mt-1">
              *A maioria dos patógenos humanos são mesófilos (37°C).
            </li>
            <li className="flex justify-between items-center pt-1">
              <span className="font-medium">Termófilos</span>
              <span className="text-red-500 font-bold">&gt; 45°C</span>
            </li>
          </ul>
        </div>

        {/* pH */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="font-bold text-green-800 text-lg mb-3 flex items-center gap-2">
            🧪 pH e Nutrição
          </h3>
          <ul className="space-y-2 text-sm text-slate-700">
             <li><strong>Neutrófilos:</strong> pH 5.5 - 8.0 (Maioria dos patógenos).</li>
             <li><strong>Acidófilos:</strong> pH baixo (<i>Lactobacillus</i>).</li>
             <li><strong>Alcalinófilos:</strong> pH alto (<i>Vibrio cholerae</i>).</li>
          </ul>
          <div className="mt-4 p-3 bg-green-50 rounded text-xs">
            <strong>Curiosidade:</strong> <i>Proteus</i> produz urease, alcalinizando a urina e formando cálculos de estruvita!
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col md:flex-row h-full bg-slate-50 overflow-hidden">
      {renderSidebar()}
      <main className="flex-1 p-6 md:p-10 overflow-y-auto custom-scrollbar">
        <div className="max-w-4xl mx-auto">
          {activeSection === 'MORPHOLOGY' && renderMorphology()}
          {activeSection === 'STRUCTURE' && renderStructure()}
          {activeSection === 'GRAM' && renderGram()}
          {activeSection === 'PHYSIOLOGY' && renderPhysiology()}
        </div>
      </main>
    </div>
  );
};

export default GeneralBacteriology;
